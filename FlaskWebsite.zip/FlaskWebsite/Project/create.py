from application import db
from application.models import Posts, Users
db.create_all()